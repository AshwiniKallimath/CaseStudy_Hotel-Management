﻿namespace HotelManagementProjectfeb.Model.DTO
{
    public class AddRoomRequest
    {
        public double room_rate { get; set; }

        public bool room_status { get; set; }
    }
}
